echo "start copy ublox_gnss.rules to /etc/udev/rules.d/"
sudo cp ublox_gnss.rules /etc/udev/rules.d

service udev reload
sleep 2
service udev restart
echo "Finish!!!"
